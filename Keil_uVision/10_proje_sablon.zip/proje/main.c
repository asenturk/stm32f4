#include "stm32f4xx.h"                  // Device header

int main(){
	
}
