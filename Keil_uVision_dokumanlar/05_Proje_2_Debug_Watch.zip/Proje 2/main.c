int main(void){
  int i;
  i=1;
  i=10;
  i=0x7FFFFFFF;
  i=i+1;
  return 0;
}
